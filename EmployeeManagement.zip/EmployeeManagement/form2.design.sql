﻿-- Insert 1
INSERT INTO [dbo].[deptdb] ([D_name])
VALUES ('Sales');

-- Insert 2  
INSERT INTO [dbo].[deptdb] ([D_name])
VALUES ('Marketing');

-- Insert 3
INSERT INTO [dbo].[deptdb] ([D_name])
VALUES ('IT');

-- Insert 4
INSERT INTO [dbo].[deptdb] ([D_name])
VALUES ('HR');

-- Insert 5
INSERT INTO [dbo].[deptdb] ([D_name])
VALUES ('Finance');