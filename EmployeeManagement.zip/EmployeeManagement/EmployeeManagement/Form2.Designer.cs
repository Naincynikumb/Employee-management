﻿namespace EmployeeManagement
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        /// 

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            textBox1 = new TextBox();
            groupBox1 = new GroupBox();
            button3 = new Button();
            groupBox2 = new GroupBox();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            button1 = new Button();
            groupBoxGender = new GroupBox();
            textBox6 = new TextBox();
            label18 = new Label();
            panel2 = new Panel();
            label17 = new Label();
            dateTimePicker1 = new DateTimePicker();
            button2 = new Button();
            Add = new Button();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox7 = new TextBox();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label7 = new Label();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            contextMenuStrip1 = new ContextMenuStrip(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            dataGridView1 = new DataGridView();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(textBox1);
            panel1.Location = new Point(6, 8);
            panel1.Name = "panel1";
            panel1.Size = new Size(1438, 49);
            panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(509, 1);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(160, 47);
            textBox1.TabIndex = 0;
            textBox1.Text = "Employee Details";
            // 
            // groupBox1
            // 
            groupBox1.AccessibleRole = AccessibleRole.None;
            groupBox1.BackColor = SystemColors.ButtonFace;
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(groupBoxGender);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(label18);
            groupBox1.Controls.Add(panel2);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(Add);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(textBox7);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Controls.Add(checkBox4);
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.ForeColor = SystemColors.ControlDarkDark;
            groupBox1.Location = new Point(-7, -204);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1451, 915);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // button3
            // 
            button3.ForeColor = Color.ForestGreen;
            button3.Location = new Point(1057, 858);
            button3.Name = "button3";
            button3.Size = new Size(130, 50);
            button3.TabIndex = 43;
            button3.Text = "update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButton4);
            groupBox2.Controls.Add(radioButton3);
            groupBox2.Location = new Point(168, 683);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(139, 127);
            groupBox2.TabIndex = 42;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBoxCity";
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.ForeColor = SystemColors.ActiveCaptionText;
            radioButton4.Location = new Point(6, 67);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(60, 24);
            radioButton4.TabIndex = 44;
            radioButton4.TabStop = true;
            radioButton4.Text = "USA";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged_1;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.ForeColor = SystemColors.ActiveCaptionText;
            radioButton3.Location = new Point(6, 26);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(65, 24);
            radioButton3.TabIndex = 43;
            radioButton3.TabStop = true;
            radioButton3.Text = "India";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged_1;
            // 
            // button1
            // 
            button1.ForeColor = Color.DarkOrange;
            button1.Location = new Point(128, 858);
            button1.Name = "button1";
            button1.Size = new Size(113, 45);
            button1.TabIndex = 41;
            button1.Text = "Clear";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBoxGender
            // 
            groupBoxGender.Location = new Point(0, 0);
            groupBoxGender.Name = "groupBoxGender";
            groupBoxGender.Size = new Size(200, 100);
            groupBoxGender.TabIndex = 40;
            groupBoxGender.TabStop = false;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(130, 280);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 37;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.ForeColor = SystemColors.ActiveCaptionText;
            label18.Location = new Point(40, 280);
            label18.Name = "label18";
            label18.Size = new Size(58, 20);
            label18.TabIndex = 36;
            label18.Text = "EmpId:";
            // 
            // panel2
            // 
            panel2.Controls.Add(label17);
            panel2.Location = new Point(24, 212);
            panel2.Name = "panel2";
            panel2.Size = new Size(1347, 49);
            panel2.TabIndex = 35;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = SystemColors.ActiveCaptionText;
            label17.Location = new Point(562, 15);
            label17.Name = "label17";
            label17.Size = new Size(176, 28);
            label17.TabIndex = 0;
            label17.Text = "Employee Details";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.AccessibleRole = AccessibleRole.None;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.Location = new Point(570, 445);
            dateTimePicker1.MinDate = new DateTime(2024, 7, 4, 0, 0, 0, 0);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(194, 27);
            dateTimePicker1.TabIndex = 33;
            dateTimePicker1.Value = new DateTime(2024, 7, 11, 0, 0, 0, 0);
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // button2
            // 
            button2.ForeColor = Color.Red;
            button2.Location = new Point(1224, 858);
            button2.Name = "button2";
            button2.Size = new Size(73, 45);
            button2.TabIndex = 34;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Add
            // 
            Add.ForeColor = SystemColors.Highlight;
            Add.Location = new Point(19, 856);
            Add.Name = "Add";
            Add.Size = new Size(73, 47);
            Add.TabIndex = 33;
            Add.Text = "Add";
            Add.UseVisualStyleBackColor = true;
            Add.Click += Add_Click;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Sales", "Marketing", "IT", "HR", "Finance" });
            comboBox2.Location = new Point(168, 597);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(73, 28);
            comboBox2.TabIndex = 32;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Bengaluru", "London", "Tokyo", "Hydrabad", "Delhi" });
            comboBox1.Location = new Point(718, 597);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(73, 28);
            comboBox1.TabIndex = 31;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(748, 683);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(268, 113);
            textBox7.TabIndex = 28;
            textBox7.TextChanged += textBox7_TextChanged;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = SystemColors.ActiveCaptionText;
            label16.Location = new Point(647, 683);
            label16.Name = "label16";
            label16.Size = new Size(70, 20);
            label16.TabIndex = 27;
            label16.Text = "Address:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = SystemColors.ActiveCaptionText;
            label15.Location = new Point(24, 683);
            label15.Name = "label15";
            label15.Size = new Size(119, 20);
            label15.TabIndex = 26;
            label15.Text = "Office Location:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = SystemColors.ActiveCaptionText;
            label14.Location = new Point(645, 597);
            label14.Name = "label14";
            label14.Size = new Size(40, 20);
            label14.TabIndex = 25;
            label14.Text = "City:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(30, 597);
            label7.Name = "label7";
            label7.Size = new Size(98, 20);
            label7.TabIndex = 24;
            label7.Text = "Department:";
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.ForeColor = SystemColors.ActiveCaptionText;
            radioButton2.Location = new Point(471, 387);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(80, 24);
            radioButton2.TabIndex = 23;
            radioButton2.TabStop = true;
            radioButton2.Text = "Female";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.ForeColor = SystemColors.ActiveCaptionText;
            radioButton1.Location = new Point(189, 387);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(64, 24);
            radioButton1.TabIndex = 22;
            radioButton1.TabStop = true;
            radioButton1.Text = "Male";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.ForeColor = SystemColors.ActiveCaptionText;
            checkBox4.Location = new Point(647, 530);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(58, 24);
            checkBox4.TabIndex = 21;
            checkBox4.Text = "SQL";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.ForeColor = SystemColors.ActiveCaptionText;
            checkBox3.Location = new Point(493, 528);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(102, 24);
            checkBox3.TabIndex = 20;
            checkBox3.Text = "JavaScript";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.ForeColor = SystemColors.ActiveCaptionText;
            checkBox2.Location = new Point(168, 528);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(62, 24);
            checkBox2.TabIndex = 19;
            checkBox2.Text = "Java";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.ForeColor = SystemColors.ActiveCaptionText;
            checkBox1.Location = new Point(331, 526);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(49, 24);
            checkBox1.TabIndex = 18;
            checkBox1.Text = "C#";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(570, 351);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(73, 27);
            textBox5.TabIndex = 16;
            textBox5.UseSystemPasswordChar = true;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(128, 354);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(73, 27);
            textBox4.TabIndex = 15;
            textBox4.TextChanged += textBox4_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(570, 318);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(73, 27);
            textBox3.TabIndex = 14;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(570, 273);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(73, 27);
            textBox2.TabIndex = 13;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = SystemColors.ActiveCaptionText;
            label13.Location = new Point(670, 525);
            label13.Name = "label13";
            label13.Size = new Size(36, 20);
            label13.TabIndex = 12;
            label13.Text = "SQL";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = SystemColors.ActiveCaptionText;
            label12.Location = new Point(518, 525);
            label12.Name = "label12";
            label12.Size = new Size(80, 20);
            label12.TabIndex = 11;
            label12.Text = "JavaScript";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = SystemColors.ActiveCaptionText;
            label11.Location = new Point(200, 525);
            label11.Name = "label11";
            label11.Size = new Size(37, 20);
            label11.TabIndex = 10;
            label11.Text = "java";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = SystemColors.ActiveCaptionText;
            label10.Location = new Point(356, 525);
            label10.Name = "label10";
            label10.Size = new Size(25, 20);
            label10.TabIndex = 9;
            label10.Text = "c#";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(33, 525);
            label9.Name = "label9";
            label9.Size = new Size(48, 20);
            label9.TabIndex = 8;
            label9.Text = "Skills:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(493, 452);
            label8.Name = "label8";
            label8.Size = new Size(48, 20);
            label8.TabIndex = 7;
            label8.Text = "D.O.J:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(210, 384);
            label6.Name = "label6";
            label6.Size = new Size(43, 20);
            label6.TabIndex = 5;
            label6.Text = "Male";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(36, 391);
            label5.Name = "label5";
            label5.Size = new Size(65, 20);
            label5.TabIndex = 4;
            label5.Text = "Gender:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(471, 351);
            label4.Name = "label4";
            label4.Size = new Size(80, 20);
            label4.TabIndex = 3;
            label4.Text = "Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(36, 354);
            label3.Name = "label3";
            label3.Size = new Size(60, 20);
            label3.TabIndex = 2;
            label3.Text = "Lname:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(474, 321);
            label2.Name = "label2";
            label2.Size = new Size(51, 20);
            label2.TabIndex = 1;
            label2.Text = "Email:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(471, 276);
            label1.Name = "label1";
            label1.Size = new Size(60, 20);
            label1.TabIndex = 0;
            label1.Text = "Fname:";
            label1.Click += label1_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(-1, 710);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1392, 168);
            dataGridView1.TabIndex = 2;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1393, 874);
            Controls.Add(dataGridView1);
            Controls.Add(groupBox1);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBoxGender;
        private Panel panel1;
        private TextBox textBox1;
        private GroupBox groupBox1;
        private Label label1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label6;
        private Label label5;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label7;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private ContextMenuStrip contextMenuStrip1;
        private TextBox textBox7;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private Button Add;
        private Button button2;
        private DateTimePicker dateTimePicker1;
        private Panel panel2;
        private Label label17;
        private DataGridView dataGridView1;
        private Label label18;
        private TextBox textBox6;
        private Button button1;
        private GroupBox groupBox2;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private Button button3;
    }
}