﻿-- Insert 1
INSERT INTO [dbo].[citydb] ([city_name])
VALUES ('Bengaluru');

-- Insert 2  
INSERT INTO [dbo].[citydb] ([city_name])
VALUES ('London');

-- Insert 3
INSERT INTO [dbo].[citydb] ([city_name])
VALUES ('Tokyo');

-- Insert 4
INSERT INTO [dbo].[citydb] ([city_name])
VALUES ('Hydrabad');

-- Insert 5
INSERT INTO [dbo].[citydb] ([city_name])
VALUES ('Delhi');