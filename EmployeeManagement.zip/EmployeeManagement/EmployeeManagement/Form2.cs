﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace EmployeeManagement
{
    public partial class Form2 : Form
    {

        List<string> skills = new List<string>();
        byte gender;
        string Location = string.Empty;
        string Department = string.Empty;
        string City = string.Empty;
        SqlConnection Con = new SqlConnection(@"Server=DESKTOP-C5EJ9AE\SQLEXPRESS;Database=employeedb;Trusted_Connection = True;");


        public Form2()
        {

            InitializeComponent();
        }




        private void label1_Click(object sender, EventArgs e)
        {
            BindData();

        }

        void BindData()
        {
            SqlCommand cnn = new SqlCommand("Select * from emptab", Con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void Add_Click(object sender, EventArgs e)
        {
            int dept_Id = 0;
            string dept = comboBox2.SelectedItem.ToString();
            if (dept == "Sales") { dept_Id = 21; }
            else if (dept == "Marketing") { dept_Id = 22; }
            else if (dept == "IT") { dept_Id = 23; }
            else if (dept == "HR") { dept_Id = 24; }
            else if (dept == "Finance") { dept_Id = 25; }

            int city_Id = 0;
            string city = comboBox1.SelectedItem.ToString();
            if (city == "Bengaluru") { city_Id = 11; }
            else if (city == "London") { city_Id = 12; }
            else if (city == "Tokyo") { city_Id = 13; }
            else if (city == "Hydrabad") { city_Id = 14; }
            else if (city == "Delhi") { city_Id = 15; }

            if (!ValidateFields()) return;

            try
            {
                Con.Open();
                SqlCommand cnn = new SqlCommand("Insert into emptab(Fname,Lname,Email,Password,Gender,Joining_date,Skills,Department_Id,City_Id,Location,Address)values(@Fname,@Lname,@Email,@Password,@Gender,@Joining_date,@Skills,@Department_Id,@City_Id,@Location,@Address)", Con);
                //cnn.Parameters.AddWithValue("@EmpId", int.Parse(textBox6.Text));            
                cnn.Parameters.AddWithValue("@Fname", textBox2.Text);
                cnn.Parameters.AddWithValue("@Lname", textBox4.Text);
                cnn.Parameters.AddWithValue("@Email", textBox3.Text);
                cnn.Parameters.AddWithValue("@Password", int.Parse(textBox5.Text));
                cnn.Parameters.AddWithValue("@Gender", gender);
                cnn.Parameters.AddWithValue("@Joining_date", dateTimePicker1.Text);
                cnn.Parameters.AddWithValue("@Skills", string.Join(",", skills));
                cnn.Parameters.AddWithValue("@Department_Id", dept_Id);
                cnn.Parameters.AddWithValue("@City_Id", city_Id);
                cnn.Parameters.AddWithValue("@Location", Location);
                cnn.Parameters.AddWithValue("@Address", textBox7.Text);
                cnn.ExecuteNonQuery();
                MessageBox.Show("Record inserted successfully!");
                Con.Close();
                BindData();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private bool ValidateFields()
        {
            if (!ValidateEmail(textBox3.Text))
            {
                MessageBox.Show("Invalid email format.");
                return false;
            }

            if (!ValidateName(textBox2.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            { 
                MessageBox.Show("First name is not valid.");
                return false;
        }
          if (!ValidateName(textBox4.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Last name is not valid.");
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBox5.Text) || textBox5.Text.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters long.");
                return false;
            }

            return true;
        }

        private bool ValidateEmail(string email)
        {
            var emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }
        private bool ValidateName(string name)
        {
            var namePattern = @"^[a-zA-Z]*$";
            return Regex.IsMatch(name, namePattern);
        }



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = 1;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
                skills.Add("Java");
            else
                skills.Remove("Java");
        }



        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                skills.Add("C#");
            else
                skills.Remove("C#");
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                skills.Add("JavaScript");
            else
                skills.Remove("JavaScript");

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
                skills.Add("SQL");
            else
                skills.Remove("SQL");

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Department = comboBox2.SelectedItem.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            City = comboBox1.SelectedItem.ToString();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = 0;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Location = "India";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Location = "USA";
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox4.Text = "";
            textBox3.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            dateTimePicker1.Value = DateTime.Now;
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;


            skills.Clear();


            gender = 0;
            Location = string.Empty;
            Department = string.Empty;
            City = string.Empty;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int empId;
            if (int.TryParse(textBox6.Text, out empId))
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM emptab WHERE Id = @Id", Con);
                    cmd.Parameters.AddWithValue("@Id", empId);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record deleted successfully!");
                        BindData();
                    }
                    else
                    {
                        MessageBox.Show("No record found with the provided ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    Con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid ID for deletion.");
            }
        }

        private void radioButton3_CheckedChanged_1(object sender, EventArgs e)
        {
            Location = "India";
        }

        private void radioButton4_CheckedChanged_1(object sender, EventArgs e)
        {
            Location = "USA";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!ValidateFields()) return;
            string email = textBox3.Text;

            if (string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Please enter an email for the update.");
                return;
            }

            int dept_Id = 0;
            string dept = comboBox2.SelectedItem?.ToString();
            if (dept == "Sales") { dept_Id = 21; }
            else if (dept == "Marketing") { dept_Id = 22; }
            else if (dept == "IT") { dept_Id = 23; }
            else if (dept == "HR") { dept_Id = 24; }
            else if (dept == "Finance") { dept_Id = 25; }

            int city_Id = 0;
            string city = comboBox1.SelectedItem?.ToString();
            if (city == "Bengaluru") { city_Id = 11; }
            else if (city == "London") { city_Id = 12; }
            else if (city == "Tokyo") { city_Id = 13; }
            else if (city == "Hydrabad") { city_Id = 14; }
            else if (city == "Delhi") { city_Id = 15; }

            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("UPDATE emptab SET Fname = @Fname, Lname = @Lname, Password = @Password, Gender = @Gender, Joining_date = @Joining_date, Skills = @Skills, Department_Id = @Department_Id, City_Id = @City_Id, Location = @Location, Address = @Address WHERE Email = @Email", Con);

                cmd.Parameters.AddWithValue("@Fname", textBox2.Text);
                cmd.Parameters.AddWithValue("@Lname", textBox4.Text);
                cmd.Parameters.AddWithValue("@Password", int.Parse(textBox5.Text));
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Joining_date", dateTimePicker1.Text);
                cmd.Parameters.AddWithValue("@Skills", string.Join(",", skills));
                cmd.Parameters.AddWithValue("@Department_Id", dept_Id);
                cmd.Parameters.AddWithValue("@City_Id", city_Id);
                cmd.Parameters.AddWithValue("@Location", Location);
                cmd.Parameters.AddWithValue("@Address", textBox7.Text);
                cmd.Parameters.AddWithValue("@Email", email);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully!");
                    BindData();
                }
                else
                {
                    MessageBox.Show("No record found with the provided email.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                Con.Close();
            }
        }

    }
    }

    

